# Location Breadcrumb UX Design Ideas

## Problem Statement
Long location chains (e.g., "Azeroth > Eastern Kingdoms > Eastern Plaguelands > ...") get truncated in the header, making it difficult for users to see the full path.

Current behavior: Text truncates with ellipsis when it exceeds the left panel width.

---

## Design Options

### Option 1: Tooltip on Hover ⭐ **RECOMMENDED**
**Implementation:** Keep text truncated but show full path in tooltip on hover

**Pros:**
- Simple to implement (GameTooltip)
- Familiar WoW pattern
- No layout changes needed
- Clean visual appearance

**Cons:**
- Requires hover interaction
- Not visible at a glance

**Example:**
```
Header: "Azeroth > Eastern Kingdoms > East..."
Tooltip: Shows full path when hovering over the text
```

---

### Option 2: Smart Truncation (First + Last)
**Implementation:** Show first segment + last segment with "..." in middle

**Pros:**
- Shows both start and destination
- No interaction required
- Maintains spatial context

**Cons:**
- Middle segments completely hidden
- Might be confusing for nested locations

**Example:**
```
Short: "Azeroth > Eastern Kingdoms > Dalaran"
Long:  "Azeroth > ... > Stratholme"
```

---

### Option 3: Reverse Truncation (Show Last N)
**Implementation:** Truncate from the start, show the most specific location

**Pros:**
- Most specific info (current location) always visible
- Common in file browsers
- Users care more about "where" than "planet"

**Cons:**
- Loses context of realm/continent

**Example:**
```
Short: "Azeroth > Eastern Kingdoms > Dalaran"
Long:  "... > Eastern Plaguelands > Stratholme"
```

---

### Option 4: Clickable Breadcrumb Navigation
**Implementation:** Each segment is a clickable link that navigates to that level

**Pros:**
- Provides navigation functionality
- Industry standard (web breadcrumbs)
- Very clear hierarchy

**Cons:**
- Significant implementation effort
- Still need truncation for very long paths
- Changes expected interaction model

**Example:**
```
[Azeroth] > [Eastern Kingdoms] > [Eastern Plaguelands] > ...
(each segment clickable to jump to that level)
```

---

### Option 5: Two-Line Layout
**Implementation:** Split path across two lines in header

**Pros:**
- No truncation needed
- All info visible
- No interaction required

**Cons:**
- Takes more vertical space
- Header becomes taller
- May not fit very long paths anyway

**Example:**
```
Line 1: Azeroth > Eastern Kingdoms > Eastern Plaguelands
Line 2: Stratholme • 45 books in this location
```

---

### Option 6: Scrollable/Marquee Text
**Implementation:** Text scrolls horizontally (auto or on hover)

**Pros:**
- Shows full path eventually
- No permanent space cost

**Cons:**
- Annoying animation
- Anti-pattern in WoW UI
- Poor usability

**Example:**
```
Text slowly scrolls: "Azeroth > Eastern Kingdoms > ..."
```
**Status:** ❌ Not recommended

---

### Option 7: Popout Info Panel
**Implementation:** Click icon/button to show full location info in small panel

**Pros:**
- Clean header
- Can show additional metadata
- Scalable for future features

**Cons:**
- Requires extra click
- Added complexity
- Non-standard for WoW

**Example:**
```
Header: "Azeroth > East... [ℹ]"
Click [ℹ] opens small panel with full path + stats
```

---

### Option 8: Dynamic Font Size
**Implementation:** Reduce font size when path is too long

**Pros:**
- All text visible
- No interaction needed

**Cons:**
- Text becomes hard to read
- Inconsistent visual style
- Anti-pattern

**Status:** ❌ Not recommended

---

## Recommended Solution: Hybrid Approach

### Primary: **Option 1 (Tooltip) + Option 3 (Smart Truncation)**

**Implementation:**
1. Display path with smart truncation (show last 2-3 segments)
2. Add full-path tooltip on hover
3. Style truncated text with subtle indicator (slightly dimmer color for "...")

**Example behavior:**
```
Short path: "Azeroth > Dalaran • 12 books in this location"
Long path:  "... > Eastern Plaguelands > Stratholme • 45 books"
Hover:      Tooltip shows "Azeroth > Eastern Kingdoms > Eastern Plaguelands > Stratholme"
```

**Why this works:**
- ✅ Users see the most relevant info (current location)
- ✅ Full context available on demand (hover)
- ✅ Minimal code changes
- ✅ Follows WoW UI conventions
- ✅ No additional screen space required
- ✅ Works for paths of any length

---

## Implementation Notes

### For Tooltip Approach:
```lua
-- In BookArchivist_UI_List_Layout.lua
headerCount:SetScript("OnEnter", function(self)
  local fullPath = ListUI:GetLocationBreadcrumbText()
  if fullPath and fullPath:len() > 40 then -- Show tooltip only if truncated
    GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
    GameTooltip:SetText(fullPath, 1, 1, 1, true)
    GameTooltip:Show()
  end
end)
headerCount:SetScript("OnLeave", function()
  GameTooltip:Hide()
end)
headerCount:EnableMouse(true) -- Make it hoverable
```

### For Smart Truncation:
```lua
-- In BookArchivist_UI_List_Location.lua
function ListUI:GetLocationBreadcrumbText(maxSegments)
  local state = getLocationState(self)
  local path = state.path or {}
  if #path == 0 then
    return t("LOCATIONS_BREADCRUMB_ROOT")
  end
  
  -- Smart truncation: show last N segments
  maxSegments = maxSegments or 3
  if #path > maxSegments then
    local visible = {}
    for i = #path - maxSegments + 1, #path do
      table.insert(visible, path[i])
    end
    return "... > " .. table.concat(visible, " > ")
  end
  
  return table.concat(path, " > ")
end
```

---

## Alternative: Future Enhancement

If we want to go further, **Option 4 (Clickable Breadcrumbs)** would be excellent for navigation but requires:
- Changing header text to interactive frame elements
- Handling click events to navigate up the tree
- Managing layout of multiple clickable segments

This could be a Phase 2 improvement once the basic tooltip solution is validated.

---

## Decision Required

Which approach should we implement?

1. ⭐ **Tooltip + Smart Truncation** (recommended, low effort, high value)
2. **Clickable Breadcrumbs** (high effort, excellent UX, future work)
3. **Two-line layout** (simple, but uses more space)
4. Other combination?
